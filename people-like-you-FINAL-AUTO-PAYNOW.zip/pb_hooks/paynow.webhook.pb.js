// ============================================================
// PAYNOW WEBHOOK HANDLER — Server-side automatic verification
// Place this file in your PocketBase pb_hooks folder on Render
// ============================================================

// This hook runs on the PocketBase server and receives
// PayNow's server-to-server payment notifications automatically

routerAdd("POST", "/paynow-webhook", (c) => {
    const data = new DynamicModel({
        reference: "",
        paynowreference: "",
        amount: "",
        status: "",
        pollurl: "",
        hash: ""
    });

    c.bind(data);

    console.log("PayNow webhook received:", JSON.stringify(data));

    try {
        // Find the payment record by reference
        const payment = $app.dao().findFirstRecordByData("payments", "reference", data.reference);

        if (!payment) {
            console.log("Payment not found for reference:", data.reference);
            return c.json(200, { status: "not_found" });
        }

        // Verify the amount matches
        const expectedAmount = payment.get("amount");
        const receivedAmount = parseFloat(data.amount);

        if (Math.abs(expectedAmount - receivedAmount) > 0.01) {
            console.log("Amount mismatch. Expected:", expectedAmount, "Received:", receivedAmount);
            return c.json(200, { status: "amount_mismatch" });
        }

        // Update payment status based on PayNow status
        // Status: Paid = 2, Cancelled = 4, Failed = 5
        let newStatus = "pending";
        if (data.status === "Paid" || data.status === "2") {
            newStatus = "paid";
            payment.set("status", "paid");
            payment.set("paid_at", new Date().toISOString());

            // If this is a shop order, also update the order
            try {
                const order = $app.dao().findFirstRecordByData("orders", "id", payment.get("item_id"));
                if (order) {
                    order.set("status", "paid");
                    $app.dao().saveRecord(order);
                }
            } catch (e) {
                // Not a shop order, that's fine
            }

        } else if (data.status === "Cancelled" || data.status === "4") {
            newStatus = "cancelled";
            payment.set("status", "cancelled");
        } else if (data.status === "Failed" || data.status === "5") {
            newStatus = "failed";
            payment.set("status", "failed");
        }

        $app.dao().saveRecord(payment);
        console.log("Payment updated:", data.reference, "->", newStatus);

        return c.json(200, { status: "ok", payment_status: newStatus });

    } catch (e) {
        console.log("Webhook error:", e.message);
        return c.json(200, { status: "error", message: e.message });
    }
});

// Also handle GET for return URL fallback
routerAdd("GET", "/paynow-webhook", (c) => {
    const reference = c.queryParam("reference");
    const status = c.queryParam("status");

    if (!reference) {
        return c.json(400, { status: "missing_reference" });
    }

    try {
        const payment = $app.dao().findFirstRecordByData("payments", "reference", reference);
        if (!payment) {
            return c.json(404, { status: "not_found" });
        }

        // If already paid by webhook, just return success
        if (payment.get("status") === "paid") {
            return c.json(200, { status: "already_paid" });
        }

        // Otherwise update based on return URL status
        if (status === "ok" || status === "paid") {
            payment.set("status", "paid");
            payment.set("paid_at", new Date().toISOString());
            $app.dao().saveRecord(payment);
            return c.json(200, { status: "paid" });
        }

        return c.json(200, { status: payment.get("status") });

    } catch (e) {
        return c.json(200, { status: "error", message: e.message });
    }
});

console.log("PayNow webhook handler loaded. Endpoint: /paynow-webhook");
