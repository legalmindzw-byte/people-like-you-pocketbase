const CACHE_NAME = 'people-like-you-final';
const urlsToCache = [
    './',
    './index.html',
    './stories.html',
    './story.html',
    './register.html',
    './login.html',
    './dashboard.html',
    './shop.html',
    './cart.html',
    './checkout.html',
    './manuscripts.html',
    './manuscript.html',
    './mentorship.html',
    './payment.html',
    './paynow-success.html',
    './license.html',
    './styles.css',
    './app.js',
    './paynow-config.js',
    './manifest.json'
];

self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => cache.addAll(urlsToCache))
    );
    self.skipWaiting();
});

self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.filter(name => name !== CACHE_NAME)
                    .map(name => caches.delete(name))
            );
        })
    );
    self.clients.claim();
});

self.addEventListener('fetch', event => {
    if (event.request.url.includes('onrender.com') || event.request.url.includes('pocketbase') || event.request.url.includes('paynow')) {
        event.respondWith(
            fetch(event.request).catch(() => {
                return new Response(JSON.stringify({ error: 'Offline' }), {
                    headers: { 'Content-Type': 'application/json' }
                });
            })
        );
        return;
    }

    event.respondWith(
        caches.match(event.request)
            .then(response => {
                if (response) return response;
                return fetch(event.request).then(networkResponse => {
                    if (networkResponse.ok) {
                        const clone = networkResponse.clone();
                        caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
                    }
                    return networkResponse;
                });
            })
            .catch(() => {
                return caches.match('./index.html');
            })
    );
});
