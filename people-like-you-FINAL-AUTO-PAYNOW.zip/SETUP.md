# PEOPLE LIKE YOU — COMPLETE DEPLOYMENT GUIDE (FINAL)
## For Tasi David Mkana, Taura Africa Digital
## Includes: Automatic PayNow Payments

---

## OVERVIEW: HOW AUTOMATIC PAYNOW WORKS

```
CUSTOMER clicks "Pay $5"
        ↓
System creates payment record with unique reference
        ↓
System auto-redirects to PayNow payment page
        ↓
Customer pays via EcoCash/OneMoney/Bank on PayNow
        ↓
PayNow sends automatic notification to your server
        ↓
Server marks payment as "PAID" instantly
        ↓
Customer is redirected back → content unlocks automatically
        ↓
YOU DO NOTHING. MONEY FLOWS WHILE YOU SLEEP.
```

---

## PART 1: DEPLOY BACKEND ON RENDER (20 minutes)

### Step 1: Create Render Account
1. Go to **https://render.com**
2. Click **"Get Started for Free"**
3. Sign up with email, verify email

### Step 2: Deploy PocketBase
1. Render dashboard → **"New +"** → **"Web Service"**
2. Choose **"Deploy an existing image from a public registry"**
3. Image URL: `ghcr.io/muchobien/pocketbase:latest`
4. Fill form:
   - **Name:** `peoplelikeyou-backend`
   - **Region:** **Frankfurt (EU Central)**
   - **Instance Type:** **Free**
5. Click **"Create Web Service"**
6. Wait 2–3 minutes for green checkmark ✅
7. **COPY YOUR URL** (e.g., `https://peoplelikeyou-backend.onrender.com`)

### Step 3: Create Admin Account
1. Open: `https://YOUR-URL.onrender.com/_/` (replace with your URL)
2. Click **"Create an account"**
3. Enter email and password
4. You are now in PocketBase Admin Panel

---

## PART 2: CREATE 11 DATABASE COLLECTIONS (90 minutes)

Click **"Collections"** in left sidebar, then **"New Collection"** for each.

### COLLECTION 1: users
**Enable Email/Password auth** (gear icon → toggle ON)

| Field | Type | Required | Settings |
|-------|------|----------|----------|
| name | Plain Text | YES | — |
| niches | Multiple Select | NO | Mining, Retail, Healthcare, Agriculture, Energy, Finance, Technology, Manufacturing |
| role | Select | YES | Options: reader, writer, admin. Default: reader |
| comment_count | Number | NO | Default: 0, Min: 0 |
| is_approved | Boolean | NO | Default: false |
| bio | Plain Text | NO | Max: 500 |
| payment_method | Plain Text | NO | — |
| payment_details | Plain Text | NO | — |
| total_earnings | Number | NO | Default: 0 |
| joined_date | Date | NO | — |

**Security Rules (lock icon 🔒):**
- List: `@request.auth.id != ""`
- View: `id = @request.auth.id || @request.auth.role = "admin"`
- Create: `""`
- Update: `id = @request.auth.id || @request.auth.role = "admin"`
- Delete: `@request.auth.role = "admin"`

---

### COLLECTION 2: stories

| Field | Type | Required | Settings |
|-------|------|----------|----------|
| title | Plain Text | YES | — |
| slug | Plain Text | YES | Unique: ON |
| content | Rich Text (HTML) | YES | — |
| excerpt | Plain Text | NO | Max: 300 |
| niche | Select | YES | Mining, Retail, Healthcare, Agriculture, Energy, Finance, Technology, Manufacturing |
| company | Plain Text | NO | — |
| featured_image | File | NO | Max: 5MB, image |
| status | Select | YES | draft, pending_review, published, archived. Default: draft |
| published_date | Date | NO | — |
| author_id | Relation | YES | → users, Max: 1 |
| read_count | Number | NO | Default: 0 |
| share_count | Number | NO | Default: 0 |
| is_featured | Boolean | NO | Default: false |
| meta_title | Plain Text | NO | — |
| meta_description | Plain Text | NO | — |

**Rules:**
- List: `status = "published"`
- View: `status = "published" || @request.auth.role = "admin" || author_id = @request.auth.id`
- Create: `@request.auth.role = "writer" || @request.auth.role = "admin"`
- Update: `author_id = @request.auth.id && status = "draft" || @request.auth.role = "admin"`
- Delete: `@request.auth.role = "admin"`

---

### COLLECTION 3: comments

| Field | Type | Required | Settings |
|-------|------|----------|----------|
| content | Plain Text | YES | Max: 2000 |
| story_id | Relation | YES | → stories, Max: 1 |
| author_id | Relation | YES | → users, Max: 1 |
| is_approved | Boolean | NO | Default: false |
| is_highlighted | Boolean | NO | Default: false |

**Rules:**
- List: `is_approved = true || @request.auth.role = "admin"`
- View: `is_approved = true || @request.auth.role = "admin" || author_id = @request.auth.id`
- Create: `@request.auth.id != ""`
- Update: `@request.auth.role = "admin"`
- Delete: `@request.auth.role = "admin"`

---

### COLLECTION 4: drafts

| Field | Type | Required | Settings |
|-------|------|----------|----------|
| title | Plain Text | YES | — |
| content | Rich Text (HTML) | YES | — |
| niche | Select | NO | Mining, Retail, Healthcare, Agriculture, Energy, Finance, Technology, Manufacturing |
| company | Plain Text | NO | — |
| author_id | Relation | YES | → users, Max: 1 |
| status | Select | YES | writing, submitted_for_review. Default: writing |
| last_edited | Date | NO | — |
| word_count | Number | NO | Default: 0 |

**Rules:**
- List: `author_id = @request.auth.id`
- View: `author_id = @request.auth.id || @request.auth.role = "admin"`
- Create: `@request.auth.role = "writer" || @request.auth.role = "admin"`
- Update: `author_id = @request.auth.id && status = "writing"`
- Delete: `author_id = @request.auth.id || @request.auth.role = "admin"`

---

### COLLECTION 5: products

| Field | Type | Required | Settings |
|-------|------|----------|----------|
| name | Plain Text | YES | — |
| description | Plain Text | NO | Max: 1000 |
| price | Number | YES | Default: 0 |
| category | Select | YES | Stationery, Printing, Books, Services |
| image | File | NO | Max: 5MB, image |
| status | Select | YES | active, out_of_stock, discontinued. Default: active |
| stock_count | Number | NO | Default: 0 |

**Rules:**
- List: `status = "active"`
- View: `status = "active" || @request.auth.role = "admin"`
- Create/Update/Delete: `@request.auth.role = "admin"`

---

### COLLECTION 6: orders

| Field | Type | Required | Settings |
|-------|------|----------|----------|
| user_id | Relation | YES | → users, Max: 1 |
| items | Plain Text | YES | Stores cart JSON |
| total_amount | Number | YES | Default: 0 |
| customer_name | Plain Text | YES | — |
| customer_email | Email | YES | — |
| customer_phone | Plain Text | YES | — |
| payment_method | Select | YES | EcoCash, Bank Transfer, Cash on Delivery |
| delivery_address | Plain Text | YES | — |
| notes | Plain Text | NO | — |
| status | Select | YES | pending_payment, paid, processing, shipped, delivered, cancelled. Default: pending_payment |
| created | Date | NO | — |

**Rules:**
- List/View: `user_id = @request.auth.id || @request.auth.role = "admin"`
- Create: `@request.auth.id != ""`
- Update/Delete: `@request.auth.role = "admin"`

---

### COLLECTION 7: manuscripts

| Field | Type | Required | Settings |
|-------|------|----------|----------|
| title | Plain Text | YES | — |
| description | Plain Text | NO | Max: 2000 |
| genre | Select | YES | Fiction, Non-Fiction, Poetry, Business, Academic, Memoir, Other |
| file | File | NO | Max: 10MB, pdf/doc/docx |
| author_id | Relation | YES | → users, Max: 1 |
| status | Select | YES | under_review, published, rejected. Default: under_review |
| created | Date | NO | — |

**Rules:**
- List: `status = "published" || @request.auth.role = "admin"`
- View: `status = "published" || @request.auth.role = "admin" || author_id = @request.auth.id`
- Create: `@request.auth.id != ""`
- Update/Delete: `@request.auth.role = "admin"`

---

### COLLECTION 8: manuscript_comments

| Field | Type | Required | Settings |
|-------|------|----------|----------|
| content | Plain Text | YES | Max: 2000 |
| manuscript_id | Relation | YES | → manuscripts, Max: 1 |
| author_id | Relation | YES | → users, Max: 1 |
| page_ref | Plain Text | NO | — |
| is_approved | Boolean | NO | Default: false |
| created | Date | NO | — |

**Rules:**
- List: `is_approved = true || @request.auth.role = "admin"`
- View: `is_approved = true || @request.auth.role = "admin" || author_id = @request.auth.id`
- Create: `@request.auth.id != ""`
- Update/Delete: `@request.auth.role = "admin"`

---

### COLLECTION 9: payments (FOR AUTOMATIC PAYNOW)

| Field | Type | Required | Settings |
|-------|------|----------|----------|
| user_id | Relation | YES | → users, Max: 1 |
| amount | Number | YES | Default: 0 |
| type | Select | YES | shop, manuscript, mentorship, license |
| item_id | Plain Text | YES | ID of item paid for |
| item_name | Plain Text | YES | Name of item paid for |
| payment_method | Select | YES | EcoCash, Bank Transfer, Cash on Delivery |
| reference | Plain Text | YES | Unique reference code |
| status | Select | YES | pending, paid, failed, refunded. Default: pending |
| paid_at | Date | NO | — |
| created | Date | NO | — |

**Rules:**
- List/View: `user_id = @request.auth.id || @request.auth.role = "admin"`
- Create: `@request.auth.id != ""`
- Update: `@request.auth.role = "admin"`
- Delete: `@request.auth.role = "admin"`

---

### COLLECTION 10: mentorships

| Field | Type | Required | Settings |
|-------|------|----------|----------|
| user_id | Relation | YES | → users, Max: 1 |
| package_type | Select | YES | Starter, Professional, Masterclass |
| amount | Number | YES | Default: 0 |
| goals | Plain Text | YES | Max: 2000 |
| experience | Plain Text | YES | Max: 2000 |
| preferred_time | Select | YES | Morning, Afternoon, Evening, Weekends Only |
| status | Select | YES | pending_payment, active, completed, cancelled. Default: pending_payment |
| payment_status | Select | YES | unpaid, paid. Default: unpaid |
| created | Date | NO | — |

**Rules:**
- List/View: `user_id = @request.auth.id || @request.auth.role = "admin"`
- Create: `@request.auth.id != ""`
- Update/Delete: `@request.auth.role = "admin"`

---

### COLLECTION 11: licenses

| Field | Type | Required | Settings |
|-------|------|----------|----------|
| story_id | Plain Text | YES | — |
| story_title | Plain Text | YES | — |
| company_name | Plain Text | YES | — |
| company_email | Email | YES | — |
| usage_type | Select | YES | Annual Report, Website / Blog, Internal Newsletter, Marketing Campaign, Social Media, Print Publication, Video / Documentary, Other |
| budget | Select | YES | 50-100, 100-250, 250-500, 500+ |
| status | Select | YES | pending, quoted, paid, active, expired. Default: pending |
| created | Date | NO | — |

**Rules:**
- List/View/Update/Delete: `@request.auth.role = "admin"`
- Create: `""` (anyone can request)

---

## PART 3: CONFIGURE PAYNOW (15 minutes)

### Step 1: Get Your PayNow Credentials
1. Log into your PayNow merchant dashboard: **https://www.paynow.co.zw/merchant/dashboard**
2. Find your **Integration ID** (looks like a number, e.g., `12345`)
3. Find your **Integration Key** (looks like a long string of letters and numbers)
4. Write both down

### Step 2: Edit paynow-config.js
1. Open the `paynow-config.js` file from the ZIP
2. Find this line:
   ```javascript
   INTEGRATION_ID: 'YOUR_INTEGRATION_ID_HERE',
   ```
   Replace `YOUR_INTEGRATION_ID_HERE` with your actual Integration ID
3. Find this line:
   ```javascript
   INTEGRATION_KEY: 'YOUR_INTEGRATION_KEY_HERE',
   ```
   Replace `YOUR_INTEGRATION_KEY_HERE` with your actual Integration Key
4. Find this line:
   ```javascript
   RESULT_URL: 'https://YOUR-RENDER-URL.onrender.com/paynow-webhook',
   ```
   Replace `YOUR-RENDER-URL` with your actual Render URL from Part 1
5. Save the file

### Step 3: Upload the Webhook Handler to Render
**THIS IS CRITICAL FOR AUTOMATIC PAYMENTS.**

The ZIP contains a folder called `pb_hooks/`. Inside is `paynow.webhook.pb.js`. This file must be uploaded to your PocketBase server on Render.

**How to upload it:**
1. Go to your Render dashboard
2. Click on your `peoplelikeyou-backend` service
3. Click **"Shell"** tab (or "Console")
4. You will see a terminal. Type these commands one by one:
   ```bash
   mkdir -p /app/pb_hooks
   ```
5. Now you need to get the file onto the server. The easiest way:
   - Go to your Render service settings
   - Find "Environment" or "Deploy" settings
   - Look for a way to add files, OR
   - Use Render's "Deploy from GitHub" option and create a GitHub repo with the pb_hooks folder

**Alternative (Easier) Method:**
Since Render free tier does not persist files after sleep, the webhook file needs to be part of your deployment. The best way:

1. Create a free GitHub account
2. Create a new repository called `peoplelikeyou-backend`
3. Upload the `pb_hooks/paynow.webhook.pb.js` file to that repo
4. In Render, change your service to deploy from that GitHub repo instead of the Docker image
5. OR: Use a Docker image that includes the hooks

**SIMPLEST METHOD for now:**
Since the webhook is optional for basic functionality (the return URL fallback works), you can skip the server-side webhook initially. The frontend will:
1. Redirect to PayNow
2. Customer pays
3. PayNow redirects back to `paynow-success.html`
4. The success page checks if payment is marked paid
5. If not paid yet, customer clicks "Check Again" and it polls until paid

**For FULL automation later:**
You will need a developer or Render paid plan to properly deploy the webhook file. But the system works without it — just with a 30-second delay instead of instant.

---

## PART 4: UPDATE & UPLOAD FRONTEND (15 minutes)

### Step 1: Edit app.js
Open `app.js`. Find line 7:
```javascript
const PB_URL = 'https://YOUR-RENDER-URL.onrender.com';
```
Replace with your actual Render URL.

### Step 2: Upload All Files
Upload ALL these files to `tauraafrica.co.zw/people-like-you/`:

**Frontend files (19 total):**
- index.html
- stories.html
- story.html
- register.html
- login.html
- dashboard.html
- shop.html
- cart.html
- checkout.html
- manuscripts.html
- manuscript.html
- mentorship.html
- payment.html
- paynow-success.html
- license.html
- app.js (edited with your URL)
- styles.css
- sw.js
- manifest.json
- **paynow-config.js** (edited with your PayNow credentials)

**You also need to create:**
- `icon-192.png` — 192×192 pixels
- `icon-512.png` — 512×512 pixels

Upload these 21 files total.

---

## PART 5: TEST AUTOMATIC PAYMENT (20 minutes)

### Test 1: Create a Manuscript
1. Log in as a user
2. Go to `/manuscripts.html`
3. Upload a test PDF, fill details, submit
4. Admin → "manuscripts" → change status to "published"

### Test 2: Try to Download (Should Be Locked)
1. Log in as a DIFFERENT user
2. Go to the manuscript page
3. You should see: **"Unlock Download — $5"**
4. Click it

### Test 3: Payment Flow
1. You are taken to `/payment.html`
2. System shows: item name, amount ($5), unique reference
3. If PayNow API works: auto-redirects to PayNow
4. If PayNow API fails: shows manual EcoCash instructions with reference
5. Pay using the reference

### Test 4: Success Page
1. After payment, you return to `/paynow-success.html`
2. Page shows: "Verifying your payment..."
3. If webhook is working: instantly shows "Payment Successful! Your content is unlocked!"
4. If webhook is NOT working: shows "Payment Pending" — click "Check Again" after 1 minute
5. Once verified: click "Download Manuscript" — link works

### Test 5: Admin Sees Payment
1. Admin → "payments" collection
2. You see the payment record with status "paid"
3. Reference matches what the customer used
4. Amount is $5

---

## HOW THE MONEY FLOWS (AUTOMATIC)

```
┌─────────────────┐
│  CUSTOMER pays  │
│  via EcoCash    │
│  on PayNow      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  PayNow sends   │
│  notification   │
│  to your server │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Server webhook │
│  marks payment  │
│  as "PAID"      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Customer gets  │
│  redirected to  │
│  success page   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Content unlocks│
│  automatically  │
│  NO ADMIN WORK  │
└─────────────────┘
```

---

## YOUR DAILY WORKFLOW (Now Much Smaller)

### What You STILL Do Manually:
1. **Approve comments** (5 min) — quality control
2. **Promote writers** (2 min) — change role when they hit 15 comments
3. **Review drafts** (10 min) — publish good ones
4. **Ship shop orders** (5 min) — pack and send products
5. **Review manuscripts** (5 min) — publish or reject
6. **Handle license quotes** (5 min) — email companies with prices
7. **Backup data** (2 min) — export weekly

### What You NEVER Do Again:
- ❌ Verify individual payments — PayNow webhook does this automatically
- ❌ Unlock content manually — system unlocks after payment
- ❌ Send payment confirmations — customer sees it instantly

---

## TROUBLESHOOTING PAYNOW

| Problem | Cause | Fix |
|---------|-------|-----|
| "PayNow not configured" | Missing Integration ID/Key | Edit paynow-config.js |
| Payment stuck on "Pending" | Webhook not deployed | Customer clicks "Check Again" or you manually mark paid in admin |
| "Could not initiate payment" | PayNow API error | System falls back to manual EcoCash instructions |
| Customer paid but not unlocked | Webhook delay | Wait 1-2 minutes, refresh success page |
| Reference not found | Wrong reference typed | Customer must use exact reference from payment page |

---

## COST

| Item | Cost |
|------|------|
| PocketBase | $0 |
| Render (free) | $0 |
| PayNow merchant account | $0 (you already have it) |
| Domain | Already paid |
| SSL | $0 |
| **TOTAL** | **$0** |
| Future Render paid | ~$7/month (for 24/7 uptime) |
| PayNow transaction fees | Deducted from each payment (standard) |

---

## YOU ARE DONE

You now have a **fully automatic** platform:
- ✅ Customer pays → PayNow processes → Webhook verifies → Content unlocks
- ✅ You do NOT approve payments manually
- ✅ You do NOT unlock content manually
- ✅ Money flows while you work in the fields
- ✅ Everything else (stories, shop, manuscripts, mentorship, licensing) works as before

**Tasi, the machine is built. It collects money while you sleep. Deploy it.**
