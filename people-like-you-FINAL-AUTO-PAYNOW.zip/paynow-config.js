// ============================================================
// PAYNOW CONFIGURATION — EDIT THIS FILE WITH YOUR DETAILS
// ============================================================
// 1. Go to https://www.paynow.co.zw/merchant/dashboard
// 2. Copy your Integration ID and Integration Key
// 3. Paste them below
// 4. Replace YOUR-RENDER-URL with your actual Render URL
// 5. Upload this file with all other frontend files
// ============================================================

const PAYNOW_CONFIG = {
    // STEP 1: Your PayNow Integration ID (from PayNow dashboard)
    INTEGRATION_ID: 'YOUR_INTEGRATION_ID_HERE',

    // STEP 2: Your PayNow Integration Key (from PayNow dashboard)  
    INTEGRATION_KEY: 'YOUR_INTEGRATION_KEY_HERE',

    // STEP 3: PayNow API endpoints (DO NOT CHANGE THESE)
    INITIATE_URL: 'https://www.paynow.co.zw/interface/initiatetransaction',
    POLL_URL: 'https://www.paynow.co.zw/interface/checkpayment',

    // STEP 4: Your website return URL (where PayNow sends customer after payment)
    // Replace YOUR-DOMAIN with your actual domain
    RETURN_URL: 'https://tauraafrica.co.zw/people-like-you/paynow-success.html',

    // STEP 5: Your server result URL (where PayNow sends automatic notification)
    // Replace YOUR-RENDER-URL with your actual Render URL from Step 1 of SETUP.md
    RESULT_URL: 'https://YOUR-RENDER-URL.onrender.com/paynow-webhook',

    // Auto-redirect to PayNow payment page
    AUTO_REDIRECT: true
};

// Make available globally
window.PAYNOW_CONFIG = PAYNOW_CONFIG;
