// ============================================================
// PEOPLE LIKE YOU — COMPLETE APPLICATION v2
// Backend: PocketBase
// Domain: tauraafrica.co.zw/people-like-you/
// Includes: Fail-safes, Auto-reconnect, Shop, Manuscripts
// ============================================================

// ⚠️ REPLACE THIS URL WITH YOUR ACTUAL RENDER URL AFTER DEPLOYMENT
const PB_URL = 'https://YOUR-RENDER-URL.onrender.com';
const pb = new PocketBase(PB_URL);

// ============================================================
// FAIL-SAFE ENGINE — Connection Health & Auto-Retry
// ============================================================

let connectionHealthy = true;
let retryCount = 0;
const MAX_RETRIES = 5;
const RETRY_DELAYS = [2000, 3000, 5000, 8000, 12000]; // Exponential backoff

async function checkConnection() {
    try {
        await pb.health.check();
        if (!connectionHealthy) {
            connectionHealthy = true;
            retryCount = 0;
            showConnectionStatus('back');
            // Retry any queued actions
            processQueuedActions();
        }
        return true;
    } catch (e) {
        connectionHealthy = false;
        showConnectionStatus('down');
        return false;
    }
}

function showConnectionStatus(status) {
    let banner = document.getElementById('connection-banner');
    if (!banner) {
        banner = document.createElement('div');
        banner.id = 'connection-banner';
        banner.style.cssText = 'position:fixed; top:0; left:0; right:0; z-index:9999; padding:10px; text-align:center; font-weight:600; font-size:0.9rem; transition:0.3s;';
        document.body.prepend(banner);
    }
    if (status === 'down') {
        banner.textContent = '⚠️ Server waking up... Please wait 30 seconds. Your actions are saved.';
        banner.style.background = '#e74c3c';
        banner.style.color = 'white';
    } else if (status === 'back') {
        banner.textContent = '✅ Back online! Everything is working.';
        banner.style.background = '#4caf50';
        banner.style.color = 'white';
        setTimeout(() => banner.remove(), 3000);
    }
}

// Auto-check connection every 30 seconds
setInterval(checkConnection, 30000);

// Queue for offline actions
let actionQueue = JSON.parse(localStorage.getItem('ply_action_queue') || '[]');

function queueAction(type, data) {
    actionQueue.push({ type, data, timestamp: Date.now() });
    localStorage.setItem('ply_action_queue', JSON.stringify(actionQueue));
}

async function processQueuedActions() {
    if (actionQueue.length === 0) return;
    const queue = [...actionQueue];
    actionQueue = [];
    localStorage.setItem('ply_action_queue', JSON.stringify([]));

    for (const action of queue) {
        try {
            if (action.type === 'comment') await postComment(action.data.storyId, action.data.content);
            if (action.type === 'draft') await createDraft(action.data.title, action.data.content, action.data.niche, action.data.company);
            if (action.type === 'cart_add') addToCart(action.data.productId, action.data.qty);
        } catch (e) {
            console.log('Queued action failed:', e);
        }
    }
}

// Wrapper for all API calls with retry
async function safeApiCall(apiFn, errorMessage = 'Something went wrong') {
    for (let i = 0; i <= MAX_RETRIES; i++) {
        try {
            const result = await apiFn();
            connectionHealthy = true;
            retryCount = 0;
            return { success: true, data: result };
        } catch (error) {
            if (i < MAX_RETRIES) {
                const delay = RETRY_DELAYS[i] || 10000;
                await new Promise(r => setTimeout(r, delay));
            } else {
                return { success: false, error: errorMessage + ': ' + error.message };
            }
        }
    }
}

// ============================================================
// AUTHENTICATION
// ============================================================

async function registerReader(name, email, password, niches) {
    const result = await safeApiCall(async () => {
        const data = {
            email: email,
            password: password,
            passwordConfirm: password,
            name: name,
            niches: niches,
            role: 'reader',
            comment_count: 0,
            is_approved: false,
            total_earnings: 0,
            joined_date: new Date().toISOString()
        };
        const record = await pb.collection('users').create(data);
        await pb.collection('users').authWithPassword(email, password);
        return record;
    }, 'Registration failed');
    return result;
}

async function login(email, password) {
    const result = await safeApiCall(async () => {
        const authData = await pb.collection('users').authWithPassword(email, password);
        return authData.record;
    }, 'Login failed');
    return result;
}

function logout() {
    pb.authStore.clear();
    localStorage.removeItem('ply_cart');
    window.location.href = './login.html';
}

function getCurrentUser() {
    return pb.authStore.model;
}

function isLoggedIn() {
    return pb.authStore.isValid;
}

function isAdmin() {
    const user = getCurrentUser();
    return user && user.role === 'admin';
}

function isWriter() {
    const user = getCurrentUser();
    return user && (user.role === 'writer' || user.role === 'admin');
}

// ============================================================
// STORIES + LIVE HANDSHAKE (Auto-refresh)
// ============================================================

async function getPublishedStories(nicheFilter = '', page = 1) {
    let filter = 'status = "published"';
    if (nicheFilter) filter += ` && niche = "${nicheFilter}"`;
    const result = await safeApiCall(async () => {
        return await pb.collection('stories').getList(page, 20, {
            sort: '-published_date',
            filter: filter,
            expand: 'author_id'
        });
    }, 'Failed to load stories');
    return result.success ? result.data.items : [];
}

async function getStoryBySlug(slug) {
    const result = await safeApiCall(async () => {
        const story = await pb.collection('stories').getFirstListItem(`slug = "${slug}" && status = "published"`, {
            expand: 'author_id'
        });
        // Increment read count silently
        pb.collection('stories').update(story.id, { read_count: (story.read_count || 0) + 1 }).catch(() => {});
        return story;
    }, 'Story not found');
    return result.success ? result.data : null;
}

async function getFeaturedStories() {
    const result = await safeApiCall(async () => {
        return await pb.collection('stories').getList(1, 5, {
            sort: '-published_date',
            filter: 'status = "published" && is_featured = true',
            expand: 'author_id'
        });
    }, 'Failed to load featured stories');
    return result.success ? result.data.items : [];
}

// Live handshake — subscribe to new stories
let storySub = null;
function subscribeToNewStories(callback) {
    pb.collection('stories').subscribe('*', (e) => {
        if (e.action === 'create' && e.record.status === 'published') {
            callback(e.record);
        }
    });
}

function unsubscribeStories() {
    if (storySub) pb.collection('stories').unsubscribe();
}

// ============================================================
// COMMENTS
// ============================================================

async function postComment(storyId, content) {
    if (!isLoggedIn()) return { success: false, error: 'Please log in to comment' };

    if (!connectionHealthy) {
        queueAction('comment', { storyId, content });
        return { success: true, queued: true, message: 'Comment saved. Will post when connection returns.' };
    }

    const result = await safeApiCall(async () => {
        const data = {
            story_id: storyId,
            author_id: getCurrentUser().id,
            content: content,
            is_approved: false
        };
        const record = await pb.collection('comments').create(data);
        const user = getCurrentUser();
        await pb.collection('users').update(user.id, {
            comment_count: (user.comment_count || 0) + 1
        });
        return record;
    }, 'Failed to post comment');
    return result;
}

async function getApprovedComments(storyId) {
    const result = await safeApiCall(async () => {
        return await pb.collection('comments').getList(1, 100, {
            filter: `story_id = "${storyId}" && is_approved = true`,
            sort: '-created',
            expand: 'author_id'
        });
    }, 'Failed to load comments');
    return result.success ? result.data.items : [];
}

async function getMyComments() {
    if (!isLoggedIn()) return [];
    const result = await safeApiCall(async () => {
        return await pb.collection('comments').getList(1, 200, {
            filter: `author_id = "${getCurrentUser().id}"`,
            sort: '-created',
            expand: 'story_id'
        });
    }, 'Failed to load your comments');
    return result.success ? result.data.items : [];
}

function subscribeToNewComments(storyId, callback) {
    pb.collection('comments').subscribe('*', (e) => {
        if (e.record.story_id === storyId && e.record.is_approved) {
            callback(e.record);
        }
    });
}

function unsubscribeAll() {
    pb.collection('comments').unsubscribe();
    pb.collection('stories').unsubscribe();
}

// ============================================================
// WRITER DASHBOARD / PORTFOLIO
// ============================================================

async function getMyPortfolio() {
    if (!isLoggedIn()) return null;
    const userId = getCurrentUser().id;

    const storiesRes = await safeApiCall(async () => {
        return await pb.collection('stories').getList(1, 100, {
            filter: `author_id = "${userId}" && status = "published"`,
            sort: '-published_date'
        });
    }, 'Failed to load stories');

    const draftsRes = await safeApiCall(async () => {
        return await pb.collection('drafts').getList(1, 50, {
            filter: `author_id = "${userId}"`,
            sort: '-last_edited'
        });
    }, 'Failed to load drafts');

    const user = getCurrentUser();
    return {
        stories: storiesRes.success ? storiesRes.data.items : [],
        drafts: draftsRes.success ? draftsRes.data.items : [],
        stats: {
            totalStories: storiesRes.success ? storiesRes.data.totalItems : 0,
            totalDrafts: draftsRes.success ? draftsRes.data.totalItems : 0,
            totalComments: user.comment_count || 0,
            totalEarnings: user.total_earnings || 0,
            niches: user.niches || [],
            role: user.role,
            joinedDate: user.joined_date
        }
    };
}

async function createDraft(title, content, niche, company) {
    if (!isWriter()) return { success: false, error: 'Only approved writers can create drafts' };

    if (!connectionHealthy) {
        queueAction('draft', { title, content, niche, company });
        return { success: true, queued: true, message: 'Draft saved locally. Will sync when connection returns.' };
    }

    const result = await safeApiCall(async () => {
        const data = {
            title: title,
            content: content,
            niche: niche,
            company: company,
            author_id: getCurrentUser().id,
            status: 'writing',
            last_edited: new Date().toISOString(),
            word_count: content ? content.split(/\s+/).length : 0
        };
        return await pb.collection('drafts').create(data);
    }, 'Failed to create draft');
    return result;
}

async function updateDraft(draftId, updates) {
    const result = await safeApiCall(async () => {
        updates.last_edited = new Date().toISOString();
        if (updates.content) {
            updates.word_count = updates.content.split(/\s+/).length;
        }
        return await pb.collection('drafts').update(draftId, updates);
    }, 'Failed to update draft');
    return result;
}

async function submitDraftForReview(draftId) {
    const result = await safeApiCall(async () => {
        return await pb.collection('drafts').update(draftId, {
            status: 'submitted_for_review',
            last_edited: new Date().toISOString()
        });
    }, 'Failed to submit draft');
    return result;
}

// ============================================================
// SHOP — PRODUCTS, CART, ORDERS
// ============================================================

// Cart (localStorage)
function getCart() {
    return JSON.parse(localStorage.getItem('ply_cart') || '[]');
}

function saveCart(cart) {
    localStorage.setItem('ply_cart', JSON.stringify(cart));
}

function addToCart(productId, productName, price, qty = 1, image = '') {
    let cart = getCart();
    const existing = cart.find(item => item.productId === productId);
    if (existing) {
        existing.qty += qty;
    } else {
        cart.push({ productId, productName, price, qty, image });
    }
    saveCart(cart);
    return { success: true, cartCount: cart.reduce((sum, i) => sum + i.qty, 0) };
}

function removeFromCart(productId) {
    let cart = getCart().filter(item => item.productId !== productId);
    saveCart(cart);
    return { success: true };
}

function updateCartQty(productId, qty) {
    let cart = getCart();
    const item = cart.find(i => i.productId === productId);
    if (item) {
        if (qty <= 0) {
            cart = cart.filter(i => i.productId !== productId);
        } else {
            item.qty = qty;
        }
    }
    saveCart(cart);
    return { success: true };
}

function clearCart() {
    localStorage.removeItem('ply_cart');
}

function getCartTotal() {
    return getCart().reduce((sum, item) => sum + (item.price * item.qty), 0);
}

function getCartCount() {
    return getCart().reduce((sum, item) => sum + item.qty, 0);
}

// Products
async function getProducts(category = '') {
    let filter = 'status = "active"';
    if (category) filter += ` && category = "${category}"`;
    const result = await safeApiCall(async () => {
        return await pb.collection('products').getList(1, 50, {
            sort: '-created',
            filter: filter
        });
    }, 'Failed to load products');
    return result.success ? result.data.items : [];
}

async function getProductById(id) {
    const result = await safeApiCall(async () => {
        return await pb.collection('products').getOne(id);
    }, 'Product not found');
    return result.success ? result.data : null;
}

// Orders
async function createOrder(items, total, customerName, customerEmail, customerPhone, paymentMethod, deliveryAddress, notes) {
    if (!isLoggedIn()) return { success: false, error: 'Please log in to place an order' };

    const result = await safeApiCall(async () => {
        const orderData = {
            user_id: getCurrentUser().id,
            items: JSON.stringify(items),
            total_amount: total,
            customer_name: customerName,
            customer_email: customerEmail,
            customer_phone: customerPhone,
            payment_method: paymentMethod,
            delivery_address: deliveryAddress,
            notes: notes,
            status: 'pending_payment',
            created: new Date().toISOString()
        };
        return await pb.collection('orders').create(orderData);
    }, 'Failed to place order');

    if (result.success) {
        clearCart();
    }
    return result;
}

async function getMyOrders() {
    if (!isLoggedIn()) return [];
    const result = await safeApiCall(async () => {
        return await pb.collection('orders').getList(1, 50, {
            filter: `user_id = "${getCurrentUser().id}"`,
            sort: '-created'
        });
    }, 'Failed to load orders');
    return result.success ? result.data.items : [];
}

// ============================================================
// MANUSCRIPTS — Upload, Review, Comment
// ============================================================

async function getManuscripts(status = '') {
    let filter = '';
    if (status) filter = `status = "${status}"`;
    const result = await safeApiCall(async () => {
        return await pb.collection('manuscripts').getList(1, 50, {
            sort: '-created',
            filter: filter || undefined,
            expand: 'author_id'
        });
    }, 'Failed to load manuscripts');
    return result.success ? result.data.items : [];
}

async function getManuscriptById(id) {
    const result = await safeApiCall(async () => {
        return await pb.collection('manuscripts').getOne(id, { expand: 'author_id' });
    }, 'Manuscript not found');
    return result.success ? result.data : null;
}

async function uploadManuscript(title, description, genre, file) {
    if (!isLoggedIn()) return { success: false, error: 'Please log in to upload' };

    const result = await safeApiCall(async () => {
        const formData = new FormData();
        formData.append('title', title);
        formData.append('description', description);
        formData.append('genre', genre);
        formData.append('author_id', getCurrentUser().id);
        formData.append('status', 'under_review');
        formData.append('file', file);
        formData.append('created', new Date().toISOString());
        return await pb.collection('manuscripts').create(formData);
    }, 'Failed to upload manuscript');
    return result;
}

async function postManuscriptComment(manuscriptId, content, pageRef = '') {
    if (!isLoggedIn()) return { success: false, error: 'Please log in to comment' };

    const result = await safeApiCall(async () => {
        const data = {
            manuscript_id: manuscriptId,
            author_id: getCurrentUser().id,
            content: content,
            page_ref: pageRef,
            is_approved: false,
            created: new Date().toISOString()
        };
        return await pb.collection('manuscript_comments').create(data);
    }, 'Failed to post comment');
    return result;
}

async function getManuscriptComments(manuscriptId) {
    const result = await safeApiCall(async () => {
        return await pb.collection('manuscript_comments').getList(1, 100, {
            filter: `manuscript_id = "${manuscriptId}" && is_approved = true`,
            sort: '-created',
            expand: 'author_id'
        });
    }, 'Failed to load comments');
    return result.success ? result.data.items : [];
}

// ============================================================
// SOCIAL SHARING
// ============================================================

function shareStory(storyTitle, storySlug, storyExcerpt) {
    const url = `https://tauraafrica.co.zw/people-like-you/story.html?slug=${storySlug}`;
    const text = `${storyTitle} — ${storyExcerpt || 'Read this story on People Like You'}`;
    if (navigator.share) {
        navigator.share({ title: storyTitle, text: text, url: url });
    } else {
        copyToClipboard(url);
        alert('Link copied to clipboard!');
    }
}

function shareToWhatsApp(storyTitle, storySlug) {
    const url = `https://tauraafrica.co.zw/people-like-you/story.html?slug=${storySlug}`;
    const text = encodeURIComponent(`${storyTitle} — Read this story on People Like You: ${url}`);
    window.open(`https://wa.me/?text=${text}`, '_blank');
}

function shareToFacebook(storySlug) {
    const url = `https://tauraafrica.co.zw/people-like-you/story.html?slug=${storySlug}`;
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, '_blank');
}

function shareToTwitter(storyTitle, storySlug) {
    const url = `https://tauraafrica.co.zw/people-like-you/story.html?slug=${storySlug}`;
    const text = encodeURIComponent(`${storyTitle} via @PeopleLikeYou`);
    window.open(`https://twitter.com/intent/tweet?text=${text}&url=${encodeURIComponent(url)}`, '_blank');
}

function copyToClipboard(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text);
    } else {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
    }
}

// ============================================================
// UI HELPERS
// ============================================================

function formatDate(dateString) {
    if (!dateString) return '';
    const d = new Date(dateString);
    return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

function formatMoney(amount) {
    return '$' + parseFloat(amount).toFixed(2);
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function updateNav() {
    const navUser = document.getElementById('nav-user');
    const navLogin = document.getElementById('nav-login');
    const navRegister = document.getElementById('nav-register');
    const navDashboard = document.getElementById('nav-dashboard');
    const navLogout = document.getElementById('nav-logout');
    const navShop = document.getElementById('nav-shop');
    const navManuscripts = document.getElementById('nav-manuscripts');
    const cartBadge = document.getElementById('cart-badge');

    if (cartBadge) {
        const count = getCartCount();
        cartBadge.textContent = count;
        cartBadge.style.display = count > 0 ? 'inline' : 'none';
    }

    if (!navUser) return;

    if (isLoggedIn()) {
        const user = getCurrentUser();
        navUser.textContent = `Hello, ${user.name}`;
        navUser.style.display = 'inline';
        if (navLogin) navLogin.style.display = 'none';
        if (navRegister) navRegister.style.display = 'none';
        if (navDashboard) navDashboard.style.display = 'inline';
        if (navLogout) navLogout.style.display = 'inline';
    } else {
        navUser.style.display = 'none';
        if (navLogin) navLogin.style.display = 'inline';
        if (navRegister) navRegister.style.display = 'inline';
        if (navDashboard) navDashboard.style.display = 'none';
        if (navLogout) navLogout.style.display = 'none';
    }
}

document.addEventListener('DOMContentLoaded', updateNav);

// ============================================================
// PAYNOW PAYMENT HELPERS
// ============================================================

// Generate unique payment reference
function generatePaymentRef(type) {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `PLY-${type.toUpperCase()}-${timestamp}-${random}`;
}

// Record a payment in the system
async function recordPayment(amount, type, itemId, itemName, paymentMethod, reference) {
    if (!isLoggedIn()) return { success: false, error: 'Please log in' };
    const result = await safeApiCall(async () => {
        return await pb.collection('payments').create({
            user_id: getCurrentUser().id,
            amount: amount,
            type: type,
            item_id: itemId,
            item_name: itemName,
            payment_method: paymentMethod,
            reference: reference,
            status: 'pending',
            created: new Date().toISOString()
        });
    }, 'Failed to record payment');
    return result;
}

// Verify payment (admin or webhook marks as paid)
async function verifyPayment(paymentId) {
    const result = await safeApiCall(async () => {
        return await pb.collection('payments').update(paymentId, {
            status: 'paid',
            paid_at: new Date().toISOString()
        });
    }, 'Failed to verify payment');
    return result;
}

// Check if user has paid for an item
async function hasUserPaid(type, itemId) {
    if (!isLoggedIn()) return false;
    const result = await safeApiCall(async () => {
        return await pb.collection('payments').getFirstListItem(
            `user_id = "${getCurrentUser().id}" && type = "${type}" && item_id = "${itemId}" && status = "paid"`
        );
    }, '');
    return result.success;
}

async function getMyPayments() {
    if (!isLoggedIn()) return [];
    const result = await safeApiCall(async () => {
        return await pb.collection('payments').getList(1, 100, {
            filter: `user_id = "${getCurrentUser().id}"`,
            sort: '-created'
        });
    }, 'Failed to load payments');
    return result.success ? result.data.items : [];
}

// ============================================================
// MENTORSHIP
// ============================================================

async function applyForMentorship(packageType, amount, goals, experience, preferredTime) {
    if (!isLoggedIn()) return { success: false, error: 'Please log in to apply' };
    const result = await safeApiCall(async () => {
        return await pb.collection('mentorships').create({
            user_id: getCurrentUser().id,
            package_type: packageType,
            amount: amount,
            goals: goals,
            experience: experience,
            preferred_time: preferredTime,
            status: 'pending_payment',
            payment_status: 'unpaid',
            created: new Date().toISOString()
        });
    }, 'Failed to submit application');
    return result;
}

async function getMyMentorships() {
    if (!isLoggedIn()) return [];
    const result = await safeApiCall(async () => {
        return await pb.collection('mentorships').getList(1, 50, {
            filter: `user_id = "${getCurrentUser().id}"`,
            sort: '-created'
        });
    }, 'Failed to load mentorships');
    return result.success ? result.data.items : [];
}

// ============================================================
// CORPORATE LICENSING
// ============================================================

async function requestLicense(storyId, storyTitle, companyName, companyEmail, usageType, budget) {
    const result = await safeApiCall(async () => {
        return await pb.collection('licenses').create({
            story_id: storyId,
            story_title: storyTitle,
            company_name: companyName,
            company_email: companyEmail,
            usage_type: usageType,
            budget: budget,
            status: 'pending',
            created: new Date().toISOString()
        });
    }, 'Failed to submit license request');
    return result;
}

async function getLicenses() {
    const result = await safeApiCall(async () => {
        return await pb.collection('licenses').getList(1, 100, { sort: '-created' });
    }, 'Failed to load licenses');
    return result.success ? result.data.items : [];
}
